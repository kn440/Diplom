<template>
    <div class="footer">     
    </div>
  </template>
  
  <script>
  export default {
    name: 'FooterGallery',
    props: {
     
    }
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped lang="scss">
  .footer{
    width: 100%;
    height: 100px;
    margin-left: none;
    margin-right: none;
    margin-top: none;
    margin-bottom: none;
    background-color: #6ed3bb;
  }
  </style>
  