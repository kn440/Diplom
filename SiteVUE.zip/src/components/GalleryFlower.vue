<template>
    <div>
      <div  id="controls">
        <button onclick="showAll()">Показать Все</button>
        <button onclick="filterFavorites()">Показать Избранное</button>
    </div>
      <div id="gallery">
        <div 
          v-for="(flower, index) in filteredFlowers" 
          :key="index" 
          class="image-item"
          :class="{ favorite: flower.isFavorite }"
        >
          <img :src="flower.url" :alt="flower.title" />
          <div>{{ flower.title }}</div>
          <button @click="toggleFavorite(index)">
            {{ flower.isFavorite ? 'Убрать из избранного' : 'Добавить в избранное' }}
          </button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        flowers: [
          { url: require('../assets/Flower2.jpg'), title: 'Роза', isFavorite: false },
          { url: require('../assets/Flower3.jpg'), title: 'Тюльпан', isFavorite: false },
          { url: require('../assets/Flower4.jpg'), title: 'Лилия', isFavorite: false },
          { url: require('../assets/Flower5.jpg'), title: 'Орхидея', isFavorite: false },
          { url: require('../assets/Flower6.jpg'), title: 'Подсолнух', isFavorite: false },
          { url: require('../assets/Flower7.jpg'), title: 'Гербера', isFavorite: false },
          { url: require('../assets/Flower8.jpg'), title: 'Подсолнух', isFavorite: false },
          { url: require('../assets/Flower9.jpg'), title: 'Гербера', isFavorite: false },
        ],
        showFavoritesOnly: false
      };
    },
    computed: {
      filteredFlowers() {
        return this.showFavoritesOnly
          ? this.flowers.filter(flower => flower.isFavorite)
          : this.flowers;
      }
    },
    methods: {
      toggleFavorite(index) {
        this.flowers[index].isFavorite = !this.flowers[index].isFavorite;
      },
      showFavorites() {
        this.showFavoritesOnly = true;
      },
      showAll() {
        this.showFavoritesOnly = false;
      }
    }
  };
  </script>
  
  <style scoped>

  
  #controls {
    text-align: center;
    margin-bottom: 20px;
  }
  
  button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    margin: 0 10px;
    border: none;
    border-radius: 5px;
    color: white;
    background-color: #33574f;
    transition: background-color 0.3s, transform 0.2s;
}

button:hover {
    background-color: #4e8176;
}

button:active {
    transform: scale(0.98);
}
  
  #gallery {
    display: flex;
    flex-wrap: wrap;
    gap: 50px;
    justify-content: center;
  }
  
  .image-item {
    border: 1px solid #ddd;
    border-radius: 10px;
    overflow: hidden;
    width: calc(25% - 80px); 
    box-sizing: border-box;
    position: relative;
  }
  
  .image-item img {
    width: 100%;
    height: auto;
  }
  
  .image-item div {
    padding: 10px;
    text-align: center;
  }
  
  .image-item button {
    position: absolute;
    bottom: 10px;
    right: 10px;
    background-color: #ff5722;
    color: white;
    border: none;
    border-radius: 3px;
    padding: 5px 10px;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
  }
  
  .image-item button:hover {
    background-color: #e64a19;
  }
  
  .image-item button:active {
    transform: scale(0.98);
  }
  
  .favorite {
    border: 2px solid #ff5722;
  }
  </style>
  