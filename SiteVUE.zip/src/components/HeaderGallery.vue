<template>
    <div>
        <div class="header"> </div>
        <div class="s21">
            <div class="s21__text">
                <div class="s21__text__up">
                <span class="s21__text__up__title">Галерея Цветов</span>
                </div>    
            </div>
        </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HeaderGallery',
    props: {
      
    }
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped lang="scss">
  .header {
    width: 100%;
    height: 152px;
    margin-left: none;
    margin-right: none;
    margin-top: none;
    margin-bottom: none;
    background-color: #6ed3bb;
  }
  .s21 {
    width: 100%;
    height: 174px;
    margin-left: none;
    margin-right: none;
    margin-top: -80px;
    margin-bottom: none;
    position: none;
    display: flex;
    justify-content: center;
    align-items: none;}
  .s21__text {
    width: 503px;
    height: 174px;
    margin-left: none;
    margin-right: none;
    margin-top: none;
    margin-bottom: none;
    position: none;
    display: flex;
    justify-content: none;
    align-items: none;
    background-color: #FFF;
    border-top-left-radius: 10%;
    border-top-right-radius: 10%;
    flex-direction: column;
    align-items: center;
    padding: 0px;
    gap: 12px;
  }
  .s21__text__up {
    margin-top: 30px;
    width: 362px;
    text-align: center;
  }
  .s21__text__up__title {
    color: #222;
    font-family: Jost;
    font-size: 50px;
    font-weight: 400;
    position: none;
    text-align: center;
  }
  </style>