<template>
  <div id="app">
    <HeaderGallery/>
    <GalleryFlower />
    <FooterGallery/>
  </div>
</template>

<script>
import FooterGallery from './components/FooterGallery.vue';
import GalleryFlower from './components/GalleryFlower.vue';
import HeaderGallery from './components/HeaderGallery.vue';

export default {
  name: 'App',
  components: {
    GalleryFlower,
    FooterGallery,
    HeaderGallery
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
