// Глобальные переменные для хранения данных
const galleryData = [
    { url: './images/flower2.jpg', title: 'Роза', isFavorite: false },
    { url: './images/flower3.jpg', title: 'Тюльпан', isFavorite: false },
    { url: './images/flower4.jpg', title: 'Лилия', isFavorite: false },
    { url: './images/flower5.jpg', title: 'Орхидея', isFavorite: false },
    { url: './images/flower6.jpg', title: 'Подсолнух', isFavorite: false },
    { url: './images/flower7.jpg', title: 'Орхидея', isFavorite: false },
    { url: './images/flower8.jpg', title: 'Подсолнух', isFavorite: false },
    { url: './images/flower9.jpg', title: 'Гербера', isFavorite: false }
];
// Глобальные переменные для хранения данных


let showFavoritesOnly = false;

// Функция для обновления отображения галереи
function updateGallery() {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = ''; // Очистка текущего содержимого

    const filteredData = showFavoritesOnly
        ? galleryData.filter(image => image.isFavorite)
        : galleryData;

    filteredData.forEach((image, index) => {
        const imageItem = document.createElement('div');
        imageItem.className = 'image-item';
        if (image.isFavorite) {
            imageItem.classList.add('favorite');
        }

        imageItem.innerHTML = `
            <img src="${image.url}" alt="${image.title}">
            <div>${image.title}</div>
            <button onclick="toggleFavorite(${index})">
                ${image.isFavorite ? 'Убрать из избранного' : 'Добавить в избранное'}
            </button>
        `;

        gallery.appendChild(imageItem);
    });
}

// Функция для переключения избранного состояния фотографии
function toggleFavorite(index) {
    galleryData[index].isFavorite = !galleryData[index].isFavorite;
    updateGallery();
}

// Функция для фильтрации избранных фотографий
function filterFavorites() {
    showFavoritesOnly = true;
    updateGallery();
}

// Функция для отображения всех фотографий
function showAll() {
    showFavoritesOnly = false;
    updateGallery();
}

// Инициализация галереи при загрузке страницы
updateGallery();
